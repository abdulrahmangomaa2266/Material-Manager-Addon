bl_info = {
    "name": "Material Manager",
    "author": "By Abdulrahman Gomaa",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar (N) > Material Manager",
    "description": "This add-on make Backup and Restore of materials all types of materials and textures for help you to export textures and materials or need more profrmance in your project",
    "category": "Material",
}

import bpy
import os
import json
import shutil
from mathutils import Vector
from bpy.props import StringProperty
from bpy.types import Operator, Panel

# -----------------------------
# Constants
# -----------------------------
MAT_FILE_EXT = ".mat"
TEXTURES_DIR_NAME = "Textures"

# -----------------------------
# Utility Helpers
# -----------------------------

def _safe_mkdir(path: str):
    os.makedirs(path, exist_ok=True)


def _norm_path(path: str) -> str:
    return os.path.normpath(os.path.abspath(path))


def _ensure_dir_for_filepath(filepath: str):
    directory = os.path.dirname(filepath)
    if directory:
        _safe_mkdir(directory)


def _serialize_simple_rna_properties(rna, skip: set | None = None):
    data = {}
    skip = skip or set()
    try:
        props = rna.bl_rna.properties
    except Exception:
        return data

    for p in props:
        idn = p.identifier
        if idn in {"rna_type"} or idn in skip:
            continue
        if p.is_readonly or p.is_hidden or p.is_runtime:
            continue
        # Skip collections and pointers (not serializable directly)
        if p.type in {"COLLECTION", "POINTER"}:
            continue
        try:
            val = getattr(rna, idn)
        except Exception:
            continue
        # Basic JSON-serializable pruning
        if isinstance(val, (int, float, str, bool)):
            data[idn] = val
        else:
            try:
                # Vectors, Colors, arrays
                data[idn] = list(val)
            except Exception:
                # Non-serializable, skip
                pass
    return data


def _socket_identifier(sock) -> str:
    # Prefer stable identifier when available
    try:
        return sock.identifier
    except Exception:
        return sock.name


def _get_selected_objects():
    return [o for o in bpy.context.selected_objects if o and hasattr(o, "material_slots")]


def _collect_selection_materials(objects):
    mats = []
    seen = set()
    for obj in objects:
        for slot in obj.material_slots:
            m = slot.material
            if m and m.name_full not in seen:
                mats.append(m)
                seen.add(m.name_full)
    return mats


def _load_or_reuse_image(path: str) -> bpy.types.Image | None:
    """
    Load an image from path, or reuse existing if same filepath.
    """
    abs_path = bpy.path.abspath(path)
    for img in bpy.data.images:
        try:
            if bpy.path.abspath(img.filepath_raw) == abs_path:
                return img
        except Exception:
            pass
    try:
        return bpy.data.images.load(path)
    except Exception:
        return None


def _image_best_ext(image: bpy.types.Image) -> str:
    # Derive from filepath if available, else from file_format
    path = getattr(image, "filepath_raw", None) or getattr(image, "filepath", "")
    if path:
        _, ext = os.path.splitext(path)
        if ext:
            return ext.lower()
    # Fallback by file_format
    fmt = getattr(image, "file_format", "PNG").lower()
    mapping = {
        "png": ".png", "jpeg": ".jpg", "jpg": ".jpg", "tiff": ".tif", "targa": ".tga",
        "bmp": ".bmp", "hdr": ".hdr", "exr": ".exr", "psd": ".psd", "tga": ".tga",
    }
    return mapping.get(fmt, ".png")


def _sanitized_filename(name: str, ext: str) -> str:
    safe = "".join(c if c.isalnum() or c in ("-", "_", ".") else "_" for c in name)
    if not safe:
        safe = "image"
    if not safe.lower().endswith(ext.lower()):
        safe += ext
    return safe


def _save_image_to_folder(image: bpy.types.Image, textures_dir: str) -> tuple[str, str]:
    """
    Save/copy image to textures_dir.
    Returns (saved_filename, rel_path)
    """
    _safe_mkdir(textures_dir)
    ext = _image_best_ext(image)
    fname = _sanitized_filename(image.name, ext)
    dest = os.path.join(textures_dir, fname)

    src_path = getattr(image, "filepath_raw", None) or getattr(image, "filepath", "")
    src_path = bpy.path.abspath(src_path) if src_path else ""

    saved = False
    if src_path and os.path.exists(src_path):
        try:
            # Copy bytes as-is
            if os.path.abspath(src_path) != os.path.abspath(dest):
                shutil.copy2(src_path, dest)
            else:
                # Already in place
                pass
            saved = True
        except Exception:
            saved = False

    if not saved:
        # Try saving from Blender image buffer
        try:
            # Ensure directory
            _ensure_dir_for_filepath(dest)
            # Preserve current settings
            old_format = getattr(image, "file_format", None)
            # Decide a compatible format for saving
            if ext.lower() == ".jpg":
                image.file_format = 'JPEG'
            elif ext.lower() == ".png":
                image.file_format = 'PNG'
            elif ext.lower() == ".exr":
                image.file_format = 'OPEN_EXR'
            elif ext.lower() == ".hdr":
                image.file_format = 'HDR'
            elif ext.lower() in (".tif", ".tiff"):
                image.file_format = 'TIFF'
            else:
                image.file_format = 'PNG'
            image.save(filepath=dest)
            # Restore format
            if old_format is not None:
                image.file_format = old_format
            saved = True
        except Exception:
            saved = False

    rel = os.path.join(TEXTURES_DIR_NAME, os.path.basename(dest))
    return os.path.basename(dest), rel


# -----------------------------
# Serialization
# -----------------------------

def _serialize_node_tree(tree: bpy.types.NodeTree, textures_dir: str):
    data = {
        "nodes": [],
        "links": [],
    }
    if not tree:
        return data

    # Map for parent frames
    for node in tree.nodes:
        n = {
            "type": node.bl_idname,
            "name": node.name,
            "label": node.label,
            "color": list(getattr(node, "color", (0, 0, 0))),
            "location": list(getattr(node, "location", Vector((0, 0))))[:2],
            "width": getattr(node, "width", 140.0),
            "height": getattr(node, "height", 100.0),
            "hide": getattr(node, "hide", False),
            "mute": getattr(node, "mute", False),
            "parent": node.parent.name if getattr(node, "parent", None) else None,
            "props": _serialize_simple_rna_properties(node, skip={"location", "width", "height", "color", "name", "label", "parent", "select"}),
            "inputs": [],
            "outputs": [],
        }

        # Socket defaults
        for sock in node.inputs:
            sv = None
            if hasattr(sock, "default_value"):
                try:
                    dv = sock.default_value
                    sv = dv if isinstance(dv, (int, float, str, bool)) else list(dv)
                except Exception:
                    sv = None
            n["inputs"].append({
                "identifier": _socket_identifier(sock),
                "name": sock.name,
                "default_value": sv,
                "hide_value": getattr(sock, "hide_value", False),
                "enabled": getattr(sock, "enabled", True),
            })
        for sock in node.outputs:
            n["outputs"].append({
                "identifier": _socket_identifier(sock),
                "name": sock.name,
            })

        # ColorRamp capture (order-sensitive)
        try:
            cr = getattr(node, "color_ramp", None)
            if cr is not None and hasattr(cr, "elements"):
                crd = {
                    "interpolation": getattr(cr, "interpolation", None),
                    "color_mode": getattr(cr, "color_mode", None),
                    "hue_interpolation": getattr(cr, "hue_interpolation", None),
                    "elements": []
                }
                for e in cr.elements:
                    try:
                        crd["elements"].append({
                            "position": float(e.position),
                            "color": list(e.color),
                        })
                    except Exception:
                        pass
                n["color_ramp"] = crd
        except Exception:
            pass

        # Image node special capture
        image_info = None
        if node.bl_idname in {"ShaderNodeTexImage", "CompositorNodeImage", "TextureNodeImage"}:
            img = getattr(node, "image", None)
            if img is not None:
                if textures_dir:
                    try:
                        saved_name, rel = _save_image_to_folder(img, textures_dir)
                        image_info = {
                            "image_name": img.name,
                            "relative_path": rel,
                            "saved_filename": saved_name,
                        }
                    except Exception:
                        image_info = {
                            "image_name": img.name,
                            "relative_path": None,
                            "saved_filename": None,
                        }
                else:
                    # In disable snapshot mode, don't write files; keep only the image name
                    image_info = {
                        "image_name": img.name,
                        "relative_path": None,
                        "saved_filename": None,
                    }
        if image_info:
            n["image"] = image_info

        # Group node capture (reference by name)
        if node.bl_idname == "ShaderNodeGroup":
            group = getattr(node, "node_tree", None)
            if group:
                n["group_name"] = group.name

        data["nodes"].append(n)

    for link in tree.links:
        try:
            data["links"].append({
                "from_node": link.from_node.name,
                "from_socket": _socket_identifier(link.from_socket),
                "to_node": link.to_node.name,
                "to_socket": _socket_identifier(link.to_socket),
            })
        except Exception:
            # Skip broken links
            pass

    return data


def _serialize_material(mat: bpy.types.Material, textures_dir: str):
    md = {
        "name": mat.name,
        "use_nodes": getattr(mat, "use_nodes", False),
        "material_properties": _serialize_simple_rna_properties(mat),
        "node_tree": None,
    }
    if getattr(mat, "use_nodes", False) and getattr(mat, "node_tree", None):
        md["node_tree"] = _serialize_node_tree(mat.node_tree, textures_dir)
    return md


def _serialize_backup(selected_objects, textures_dir: str):
    # Objects material slots order mapping
    objects_data = []
    for obj in selected_objects:
        slots = []
        # Ensure stable ordering
        if hasattr(obj, "material_slots"):
            for s in obj.material_slots:
                try:
                    slots.append({
                        "material": (s.material.name if s.material else None),
                        "slot_name": getattr(s, "name", None),
                        "link": getattr(s, "link", None),
                    })
                except Exception:
                    slots.append(s.material.name if s.material else None)
        mesh_info = None
        try:
            me = getattr(obj, "data", None)
            polys = getattr(me, "polygons", None)
            if polys is not None:
                pidx = []
                for p in polys:
                    try:
                        pidx.append(int(p.material_index))
                    except Exception:
                        pidx.append(0)
                mesh_info = {"polygon_material_indices": pidx}
        except Exception:
            mesh_info = None

        objects_data.append({
            "object_name": obj.name,
            "object_id": str(obj.as_pointer()),
            "material_slots": slots,
            "mesh": mesh_info,
        })

    materials = _collect_selection_materials(selected_objects)
    mats_data = {}
    for m in materials:
        mats_data[m.name] = _serialize_material(m, textures_dir)

    data = {
        "schema": "MaterialManager-1.0",
        "addon_version": "1.0",
        "blender_version": bpy.app.version_string,
        "textures_dir": TEXTURES_DIR_NAME,
        "objects": objects_data,
        "materials": mats_data,
    }
    return data


# -----------------------------
# Deserialization
# -----------------------------

def _find_socket_by_identifier(node, ident: str, by_name_fallback: str | None = None):
    # Prefer identifier
    for s in node.inputs:
        if _socket_identifier(s) == ident:
            return s
    # Fallback by name
    if by_name_fallback:
        for s in node.inputs:
            if s.name == by_name_fallback:
                return s
    return None


def _restore_node_tree(tree: bpy.types.NodeTree, data: dict, base_dir: str):
    # Clear existing
    try:
        tree.nodes.clear()
        tree.links.clear()
    except Exception:
        pass

    nodes_by_name = {}

    # First pass: create nodes
    for nd in data.get("nodes", []):
        try:
            node = tree.nodes.new(nd.get("type", "ShaderNodeBsdfPrincipled"))
        except Exception:
            # Fallback to Principled BSDF
            node = tree.nodes.new("ShaderNodeBsdfPrincipled")
        node.name = nd.get("name", node.name)
        node.label = nd.get("label", "")
        try:
            node.location = Vector(nd.get("location", [0, 0]))
        except Exception:
            pass
        node.width = nd.get("width", node.width)
        node.height = nd.get("height", node.height)
        node.hide = nd.get("hide", False)
        node.mute = nd.get("mute", False)
        # Properties (best-effort)
        for k, v in (nd.get("props") or {}).items():
            try:
                setattr(node, k, v)
            except Exception:
                # Try list -> tuple
                try:
                    setattr(node, k, tuple(v))
                except Exception:
                    pass

        # Restore socket default values and flags
        in_defs = nd.get("inputs", [])
        for sdef in in_defs:
            ident = sdef.get("identifier")
            sock = _find_socket_by_identifier(node, ident, by_name_fallback=sdef.get("name"))
            if not sock:
                continue
            if hasattr(sock, "default_value"):
                dv = sdef.get("default_value")
                if dv is not None:
                    try:
                        setattr(sock, "default_value", dv)
                    except Exception:
                        try:
                            setattr(sock, "default_value", tuple(dv))
                        except Exception:
                            pass
            # Restore socket flags
            try:
                hv = sdef.get("hide_value")
                if hv is not None and hasattr(sock, "hide_value"):
                    sock.hide_value = hv
            except Exception:
                pass
            try:
                en = sdef.get("enabled")
                if en is not None and hasattr(sock, "enabled"):
                    sock.enabled = en
            except Exception:
                pass

        # Restore Group node binding
        try:
            if nd.get("type") == "ShaderNodeGroup":
                gname = nd.get("group_name")
                if gname:
                    grp = bpy.data.node_groups.get(gname)
                    if not grp:
                        try:
                            grp = bpy.data.node_groups.new(gname, 'ShaderNodeTree')
                        except Exception:
                            grp = None
                    if grp is not None:
                        try:
                            node.node_tree = grp
                        except Exception:
                            pass
        except Exception:
            pass

        # Restore ColorRamp (order-sensitive)
        try:
            crd = nd.get("color_ramp")
            cr = getattr(node, "color_ramp", None)
            if crd and cr is not None and hasattr(cr, "elements"):
                # Set ramp-level properties
                for prop in ("interpolation", "color_mode", "hue_interpolation"):
                    val = crd.get(prop)
                    if val is not None:
                        try:
                            setattr(cr, prop, val)
                        except Exception:
                            pass
                # Adjust elements count to match
                target = list(crd.get("elements", []))
                try:
                    while len(cr.elements) > len(target):
                        cr.elements.remove(cr.elements[-1])
                except Exception:
                    pass
                try:
                    while len(cr.elements) < len(target):
                        cr.elements.new(0.5)
                except Exception:
                    pass
                # Apply positions/colors in exact order
                for idx, ed in enumerate(target):
                    try:
                        e = cr.elements[idx]
                        pos = ed.get("position")
                        if pos is not None:
                            e.position = float(pos)
                        col = ed.get("color")
                        if col is not None:
                            e.color = col if isinstance(col, (list, tuple)) else [1, 1, 1, 1]
                    except Exception:
                        pass
        except Exception:
            pass

        # Special: Image nodes
        if nd.get("type") in {"ShaderNodeTexImage", "CompositorNodeImage", "TextureNodeImage"}:
            img_info = nd.get("image")
            if img_info:
                rel = img_info.get("relative_path")
                if rel:
                    img_path = os.path.join(base_dir, rel)
                    if os.path.exists(img_path):
                        img = _load_or_reuse_image(img_path)
                        if img:
                            node.image = img
                else:
                    # Fallback: bind by image name if it's already loaded
                    iname = img_info.get("image_name")
                    if iname:
                        try:
                            img = bpy.data.images.get(iname)
                            if img is not None:
                                node.image = img
                        except Exception:
                            pass

        nodes_by_name[node.name] = node

    # Second pass: re-parent frames
    for nd in data.get("nodes", []):
        parent_name = nd.get("parent")
        if parent_name and nd.get("name") in nodes_by_name and parent_name in nodes_by_name:
            try:
                nodes_by_name[nd["name"]].parent = nodes_by_name[parent_name]
            except Exception:
                pass

    # Third: links
    for lk in data.get("links", []):
        fn = nodes_by_name.get(lk.get("from_node"))
        tn = nodes_by_name.get(lk.get("to_node"))
        if not fn or not tn:
            continue
        fs = None
        ts = None
        fs_ident = lk.get("from_socket")
        ts_ident = lk.get("to_socket")
        for s in fn.outputs:
            if _socket_identifier(s) == fs_ident:
                fs = s
                break
        for s in tn.inputs:
            if _socket_identifier(s) == ts_ident:
                ts = s
                break
        if fs and ts:
            try:
                tree.links.new(fs, ts)
            except Exception:
                pass


def _restore_materials_and_assign(backup_data: dict, base_dir: str, selected_objects):
    mats_map = {}

    # Create/Update materials
    for name, md in (backup_data.get("materials") or {}).items():
        mat = bpy.data.materials.get(name)
        if not mat:
            mat = bpy.data.materials.new(name=name)
        mats_map[name] = mat
        # Material properties
        for k, v in (md.get("material_properties") or {}).items():
            try:
                setattr(mat, k, v)
            except Exception:
                try:
                    setattr(mat, k, tuple(v))
                except Exception:
                    pass
        use_nodes = bool(md.get("use_nodes", False))
        mat.use_nodes = use_nodes
        if use_nodes:
            tree_data = md.get("node_tree") or {}
            _restore_node_tree(mat.node_tree, tree_data, base_dir)

    # Assign materials to target objects in backup order
    for i, od in enumerate(backup_data.get("objects", [])):
        obj = selected_objects[i]
        slot_mats = od.get("material_slots", [])

        # Ensure this object has its own data-block to avoid affecting other users
        try:
            if hasattr(obj, "data") and getattr(obj.data, "users", 1) > 1:
                obj.data = obj.data.copy()
        except Exception:
            pass

        # Ensure the object's material slot count matches exactly the backup
        try:
            bpy.context.view_layer.objects.active = obj
        except Exception:
            pass

        # Remove extra slots if any
        try:
            while len(obj.material_slots) > len(slot_mats):
                obj.active_material_index = len(obj.material_slots) - 1
                try:
                    bpy.ops.object.material_slot_remove()
                except Exception:
                    break
        except Exception:
            pass

        # Add missing slots if any
        try:
            while len(obj.material_slots) < len(slot_mats):
                try:
                    bpy.ops.object.material_slot_add()
                except Exception:
                    break
        except Exception:
            pass

        # Assign in exact order
        for i, slot_entry in enumerate(slot_mats):
            # Support legacy schema (string) and new schema (dict)
            if isinstance(slot_entry, dict):
                mname = slot_entry.get("material")
                sname = slot_entry.get("slot_name")
                slink = slot_entry.get("link")
            else:
                mname = slot_entry
                sname = None
                slink = None

            mref = mats_map.get(mname) if mname else None
            # Ensure desired link is applied before assignment
            try:
                slot = obj.material_slots[i]
                desired_link = slink or getattr(slot, "link", 'DATA')
                if hasattr(slot, "link") and desired_link in {'DATA', 'OBJECT'}:
                    slot.link = desired_link
            except Exception:
                desired_link = 'DATA'

            # Assign via correct path depending on link
            try:
                if desired_link == 'OBJECT':
                    # Assign to the slot/material directly
                    if i < len(obj.material_slots):
                        obj.material_slots[i].material = mref
                    else:
                        # Fallback set active and assign
                        bpy.context.view_layer.objects.active = obj
                        obj.active_material_index = min(i, max(0, len(obj.material_slots) - 1))
                        try:
                            bpy.context.object.active_material = mref
                        except Exception:
                            pass
                else:
                    # DATA link: assign via mesh materials array when available
                    if getattr(obj.data, "materials", None) is not None and i < len(obj.data.materials):
                        obj.data.materials[i] = mref
                    elif getattr(obj.data, "materials", None) is not None and i == len(obj.data.materials):
                        obj.data.materials.append(mref)
                    else:
                        # Fallback to slot.material
                        if i < len(obj.material_slots):
                            obj.material_slots[i].material = mref
                        else:
                            bpy.context.view_layer.objects.active = obj
                            obj.active_material_index = min(i, max(0, len(obj.material_slots) - 1))
                            try:
                                bpy.context.object.active_material = mref
                            except Exception:
                                pass
            except Exception:
                pass

            # Apply slot metadata (name) after assignment
            try:
                slot = obj.material_slots[i]
                if sname is not None and hasattr(slot, "name"):
                    slot.name = sname
            except Exception:
                pass

        # Restore per-polygon material indices exactly
        try:
            me = getattr(obj, "data", None)
            polys = getattr(me, "polygons", None)
            saved_mesh = od.get("mesh") or {}
            saved_pidx = saved_mesh.get("polygon_material_indices")
            if polys is not None and isinstance(saved_pidx, list):
                # Ensure OBJECT mode for index assignment
                prev_mode = None
                try:
                    prev_mode = obj.mode
                except Exception:
                    prev_mode = None
                try:
                    bpy.context.view_layer.objects.active = obj
                except Exception:
                    pass
                if prev_mode and prev_mode != 'OBJECT':
                    try:
                        bpy.ops.object.mode_set(mode='OBJECT')
                    except Exception:
                        pass
                slot_count = len(obj.material_slots)
                if slot_count <= 0:
                    slot_count = 1  # avoid negative indexing
                count = min(len(polys), len(saved_pidx))
                for pi in range(count):
                    idx = saved_pidx[pi]
                    try:
                        idx_int = int(idx)
                    except Exception:
                        idx_int = 0
                    # Clamp to valid range
                    if idx_int < 0:
                        idx_int = 0
                    if idx_int >= slot_count:
                        idx_int = slot_count - 1
                    try:
                        polys[pi].material_index = idx_int
                    except Exception:
                        pass
                try:
                    me.update()
                except Exception:
                    pass
                # Restore mode
                if prev_mode and prev_mode != 'OBJECT':
                    try:
                        bpy.ops.object.mode_set(mode=prev_mode)
                    except Exception:
                        pass
        except Exception:
            pass


# -----------------------------
# Cleanup after backup
# -----------------------------

def _cleanup_selected_objects_materials_and_textures(selected_objects):
    # Detach materials from selected objects
    for obj in selected_objects:
        try:
            # Make data single-user to avoid affecting linked duplicates
            if hasattr(obj, "data") and getattr(obj.data, "users", 1) > 1:
                obj.data = obj.data.copy()
            # Clear data materials
            dm = getattr(obj.data, "materials", None)
            if dm is not None:
                dm.clear()
            # Clear material slots using data API
            while len(obj.material_slots) > 0:
                try:
                    obj.material_slots.remove(obj.material_slots[0])
                except Exception:
                    break
        except Exception:
            pass

    # Clear fake users from all materials and remove unused ones
    for m in list(bpy.data.materials):
        try:
            # Clear fake user flag
            if hasattr(m, "use_fake_user"):
                m.use_fake_user = False
        except Exception:
            pass
    
    # Remove materials that now have zero users
    to_remove = [m for m in bpy.data.materials if m.users == 0]
    for m in to_remove:
        try:
            bpy.data.materials.remove(m)
        except Exception:
            pass

    # Clear fake users from all images and remove them all (since we backup all)
    for img in list(bpy.data.images):
        try:
            # Skip special runtime buffers that cannot be removed
            if img.name in {"Render Result", "Viewer Node"}:
                continue
            # Clear fake user flag
            if hasattr(img, "use_fake_user"):
                img.use_fake_user = False
        except Exception:
            pass

    # Remove unused images (since we backed them all up, but only remove if no users)
    to_remove_imgs = [img for img in bpy.data.images if img.name not in {"Render Result", "Viewer Node"} and img.users == 0]
    for img in to_remove_imgs:
        try:
            bpy.data.images.remove(img)
        except Exception:
            pass


# -----------------------------
# Operators
# -----------------------------
class MM_OT_BackupDeleteMaterials(Operator):
    bl_idname = "material_manager.backup_delete"
    bl_label = "Backup and Delete Materials"
    bl_description = "Backup materials and textures of selected objects, then erase them from the selection."
    bl_options = {"REGISTER", "UNDO"}

    # Use file browser to get destination directory and name (folder)
    filepath: StringProperty(name="Backup Folder", subtype="FILE_PATH", description="Choose a location and name for the backup folder")

    def invoke(self, context, event):
        # Force file browser dialog
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if not self.filepath:
            self.report({'ERROR'}, "No path provided.")
            return {'CANCELLED'}

        # Derive backup folder and .mat file path
        raw_fp = _norm_path(self.filepath)
        base, fname = os.path.split(raw_fp)
        root, ext = os.path.splitext(raw_fp)

        if ext.lower() == MAT_FILE_EXT:
            # User chose a .mat path; use its stem as folder
            folder_name = os.path.splitext(os.path.basename(raw_fp))[0]
            backup_dir = os.path.join(os.path.dirname(raw_fp), folder_name)
        else:
            # Treat filepath (including optional name typed) as folder
            if fname:
                backup_dir = raw_fp
            else:
                # If only directory selected, ask for a default name with timestamp
                from datetime import datetime
                folder_name = f"MaterialBackup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                backup_dir = os.path.join(raw_fp, folder_name)

        mat_name = os.path.basename(backup_dir)
        mat_file = os.path.join(backup_dir, f"{mat_name}{MAT_FILE_EXT}")
        textures_dir = os.path.join(backup_dir, TEXTURES_DIR_NAME)

        # Prepare folders
        _safe_mkdir(backup_dir)
        _safe_mkdir(textures_dir)

        selected_objects = _get_selected_objects()
        if not selected_objects:
            self.report({'ERROR'}, "No selected objects with materials.")
            return {'CANCELLED'}

        # Serialize selection
        backup = _serialize_backup(selected_objects, textures_dir)

        # Write .mat JSON
        try:
            with open(mat_file, "w", encoding="utf-8") as f:
                json.dump(backup, f, indent=2)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to write backup: {e}")
            return {'CANCELLED'}

        # Cleanup: remove materials and textures from selected objects only
        _cleanup_selected_objects_materials_and_textures(selected_objects)

        self.report({'INFO'}, f"Backup created at: {backup_dir}")
        return {'FINISHED'}
class MM_OT_BackupMaterials(Operator):
    bl_idname = "material_manager.backup"
    bl_label = "Backup Materials"
    bl_description = "Backup image textures of selected objects without deleting them."
    bl_options = {"REGISTER", "UNDO"}

    # Use file browser to get destination directory and name (folder)
    filepath: StringProperty(name="Backup Folder", subtype="FILE_PATH", description="Choose a location and name for the backup folder")

    def invoke(self, context, event):
        # Force file browser dialog
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if not self.filepath:
            self.report({'ERROR'}, "No path provided.")
            return {'CANCELLED'}

        # Derive backup folder
        raw_fp = _norm_path(self.filepath)
        base, fname = os.path.split(raw_fp)
        root, ext = os.path.splitext(raw_fp)

        if ext.lower() == MAT_FILE_EXT:
            # User chose a .mat path; use its stem as folder
            folder_name = os.path.splitext(os.path.basename(raw_fp))[0]
            backup_dir = os.path.join(os.path.dirname(raw_fp), folder_name)
        else:
            # Treat filepath (including optional name typed) as folder
            if fname:
                backup_dir = raw_fp
            else:
                # If only directory selected, ask for a default name with timestamp
                from datetime import datetime
                folder_name = f"TextureBackup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                backup_dir = os.path.join(raw_fp, folder_name)

        textures_dir = os.path.join(backup_dir, TEXTURES_DIR_NAME)

        # Prepare folders
        _safe_mkdir(backup_dir)
        _safe_mkdir(textures_dir)

        selected_objects = _get_selected_objects()
        if not selected_objects:
            self.report({'ERROR'}, "No selected objects with materials.")
            return {'CANCELLED'}

        # Collect all unique images from selected objects' materials
        images = set()
        for obj in selected_objects:
            for slot in obj.material_slots:
                m = slot.material
                if m and getattr(m, "use_nodes", False) and m.node_tree:
                    for node in m.node_tree.nodes:
                        if node.bl_idname in {"ShaderNodeTexImage", "CompositorNodeImage", "TextureNodeImage"}:
                            img = getattr(node, "image", None)
                            if img:
                                images.add(img)

        # Save each image to textures_dir
        for img in images:
            try:
                _save_image_to_folder(img, textures_dir)
            except Exception as e:
                self.report({'WARNING'}, f"Failed to save image {img.name}: {e}")

        self.report({'INFO'}, f"Textures backed up at: {backup_dir}")
        return {'FINISHED'}



class MM_OT_RestoreMaterials(Operator):
    bl_idname = "material_manager.restore"
    bl_label = "Restore Materials"
    bl_description = "Restore materials and textures from a .mat file to the currently selected objects."
    bl_options = {"REGISTER", "UNDO"}

    filepath: StringProperty(name=".mat File", subtype="FILE_PATH", description="Select a .mat file created by Material Manager", default="", options={"HIDDEN"})
    filter_glob: StringProperty(default="*%s" % MAT_FILE_EXT, options={"HIDDEN"})

    def invoke(self, context, event):
        # Force file browser dialog filtered to .mat files
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if not self.filepath:
            self.report({'ERROR'}, "No .mat file selected.")
            return {'CANCELLED'}
        mat_path = _norm_path(self.filepath)
        if not os.path.exists(mat_path) or not mat_path.lower().endswith(MAT_FILE_EXT):
            self.report({'ERROR'}, "Invalid .mat file path.")
            return {'CANCELLED'}

        # Read backup JSON
        try:
            with open(mat_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to read .mat: {e}")
            return {'CANCELLED'}

        base_dir = os.path.dirname(mat_path)

        # Find objects in current scene that match the backed up object IDs or names
        scene = context.scene
        target_objects = []
        for od in data.get("objects", []):
            id_str = od.get("object_id")
            obj = None
            if id_str:
                for o in scene.objects:
                    if hasattr(o, "material_slots") and str(o.as_pointer()) == id_str:
                        obj = o
                        break
            if not obj:
                name = od.get("object_name")
                obj = scene.objects.get(name)
                if obj and hasattr(obj, "material_slots"):
                    pass  # already set
            if obj:
                target_objects.append(obj)

        if not target_objects:
            self.report({'ERROR'}, "No matching objects found in the current scene.")
            return {'CANCELLED'}

        _restore_materials_and_assign(data, base_dir, target_objects)

        restored_count = len(target_objects)
        self.report({'INFO'}, f"Materials restored to {restored_count} object(s).")
        return {'FINISHED'}


# -----------------------------
# UI Panel
# -----------------------------
class VIEW3D_PT_MaterialManager(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Material Manager'  # must be EXACTLY this string
    bl_label = 'Material Manager'

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator(MM_OT_BackupMaterials.bl_idname, text="Backup Materials", icon='FILE_BACKUP')
        col.operator(MM_OT_BackupDeleteMaterials.bl_idname, text="Backup and Delete Materials", icon='FILE_BACKUP')
        col.separator()
        col.operator(MM_OT_RestoreMaterials.bl_idname, text="Restore Materials", icon='FILE_REFRESH')


# -----------------------------
# Registration
# -----------------------------
CLASSES = (
    MM_OT_BackupDeleteMaterials,
    MM_OT_BackupMaterials,
    MM_OT_RestoreMaterials,
    VIEW3D_PT_MaterialManager,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
